"""
Création de Fonctions Imbriquées
"""


# Définir la fonction externe

def main():
    def fonction_externe(num1, num2, s):
        produit = num1 * num2
        print(produit)

        def fonction_interne():
            s = num1 + num2
            return s

        print(fonction_interne())
        return s + 10

    num1 = int(input("Donnez le Premier nombre: "))
    num2 = int(input("Donnez le Deuxième nombre: "))
    print(fonction_externe(num1, num2, num1 + num2))


if __name__ == "__main__":
    main()


