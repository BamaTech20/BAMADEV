"""
Ce programme permet  d'Afficher les 3 arguments suivantes: Nom, Prénom, Age
"""

"""def default_param(nom, prenom, age=30):
    print("Nom: " + prenom + nom)
    print("Age: " + str(age))

    print("Nom: " + prenom1 + nom1)
    print("Age: " + str(age))


prenom = input("Donnez le Prénom du Candidat: ")
nom = input("Donnez le Nom du Candidat: ")

prenom1 = input("Donnez le Prénom du Candidat: ")
nom1 = input("Donnez le Nom du Candidat: ")


default_param(nom, prenom, 25)
default_param(nom1, prenom1, )"""

"""
Ce programme permet  d'Afficher les 3 arguments suivantes: Nom, Prénom, Age
"""


def main():
    def default_param(nom, prenom, age=29):
        print("Nom: " + prenom + nom)
        print("Age: " + str(age))

    default_param("SECK", "Mohamed ", 26)
    default_param("SOW", "Bineta ")


if __name__ == "__main__":
    main()
