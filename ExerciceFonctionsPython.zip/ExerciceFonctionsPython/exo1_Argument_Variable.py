"""
Ce Programme permet d'afficher Verticalement une fonction à Arguments Variables
"""


def main():
    def argument_variable(variables):
        print("Resultat: ")
        for i in variables:
            print(i)

    variables = [9, -2, 20, 4]
    argument_variable(variables)


if __name__ == "__main__":
    main()
