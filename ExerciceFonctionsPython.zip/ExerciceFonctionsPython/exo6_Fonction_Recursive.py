"""
Ce programme permet d'utiliser  Fonctions récursives
"""


# Définir la Fonction Récursive avec comme paramètre n

def main():
    def recursive(n):
        if n == 0:
            return n
        else:
            return n + recursive(n - 1)

    num = int(input("Donner la valeur de l'entier: "))
    print("la somme total est ", recursive(num))


if __name__ == "__main__":
    main()

