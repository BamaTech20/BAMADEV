"""
Ce programme permet de calculer la somme de duex ou plusieurs Arguments
"""
# Définir la Fonction permettant de calculer la somme

def main():
    def argument_variable_somme(num1, num2, num3):
        return num1 + num2 + num3

    print(argument_variable_somme(4, 20, 95))


if __name__ == "__main__":
    main()



