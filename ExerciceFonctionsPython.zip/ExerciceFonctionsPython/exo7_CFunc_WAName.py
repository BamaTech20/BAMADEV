"""
Ce programme nous permet d'appeler une fonction par un autre nom
"""


def main():
    def somme_nombre_entier(val1, val2):
        return val1 + val2

    val1 = int(input("Donnez la valeur 1: "))
    val2 = int(input("Donnez la valeur 2: "))

    new_sum = somme_nombre_entier
    print(new_sum(val1, val2))


if __name__ == "__main__":
    main()


