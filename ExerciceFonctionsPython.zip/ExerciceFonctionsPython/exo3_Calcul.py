"""
Ce programme permet de faire l'addition et La soustraction de deux nombres
"""


def main():
    def calcul(num1, num2):
        return num1 + num2, num1 - num2

    print("Resultat:", calcul(26, 15))


if __name__ == "__main__":
    main()
